TERMUX_SUBPKG_DEPENDS="libwebsockets"
TERMUX_SUBPKG_INCLUDE="
bin/
share/man/
etc/
var/service/mosquitto/run
var/service/mosquitto/down
var/service/mosquitto/log/run
"
TERMUX_SUBPKG_DESCRIPTION="MQTT version 3.1/3.1.1 compatible message broker and clients"
