TERMUX_SUBPKG_INCLUDE="share/povray-*/"
TERMUX_SUBPKG_DESCRIPTION="Platform-independent data for povray"
TERMUX_SUBPKG_PLATFORM_INDEPENDENT=true
TERMUX_SUBPKG_BREAKS="povray (<< 3.8.0-beta.2-2)"
TERMUX_SUBPKG_REPLACES="povray (<< 3.8.0-beta.2-2)"
