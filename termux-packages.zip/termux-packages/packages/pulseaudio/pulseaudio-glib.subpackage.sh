TERMUX_SUBPKG_DESCRIPTION="PulseAudio GLIB mainloop component"
TERMUX_SUBPKG_DEPENDS="glib"
TERMUX_SUBPKG_INCLUDE="
share/vala/vapi/libpulse-mainloop-glib.*
include/pulse/glib-mainloop.h
lib/libpulse-mainloop-glib.so
lib/pkgconfig/libpulse-mainloop-glib.pc
"
