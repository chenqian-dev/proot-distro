TERMUX_SUBPKG_INCLUDE="
bin/
"
TERMUX_SUBPKG_DESCRIPTION="Command-line tools for libsrt"
