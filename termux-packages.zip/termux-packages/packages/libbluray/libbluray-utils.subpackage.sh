TERMUX_SUBPKG_INCLUDE="bin/"
TERMUX_SUBPKG_DESCRIPTION="Example utilities for libbluray"
