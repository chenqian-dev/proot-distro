TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Speex command line tools"
TERMUX_SUBPKG_DEPENDS="libogg, speexdsp"
