TERMUX_SUBPKG_INCLUDE="bin/ share/man/man1/"
TERMUX_SUBPKG_DESCRIPTION="Display dialog boxes from shell scripts"
TERMUX_SUBPKG_DEPENDS="libpopt"
TERMUX_SUBPKG_CONFLICTS="dialog (<< 1.3-20211214)"
