TERMUX_SUBPKG_DESCRIPTION="Library for debuginfod"
TERMUX_SUBPKG_INCLUDE="lib/libdebuginfod*.so* include/elfutils/debuginfod.h lib/pkgconfig/libdebuginfod.pc share/man/man3/debuginfod_*"
TERMUX_SUBPKG_DEPENDS="libcurl"
