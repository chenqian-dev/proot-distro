TERMUX_SUBPKG_INCLUDE="
lib/libvaladoc*.a
lib/libvaladoc*.la
lib/valadoc*/**/*.a
lib/valadoc*/**/*.la
"
TERMUX_SUBPKG_DESCRIPTION="Static libraries for valadoc"
TERMUX_SUBPKG_DEPENDS="valadoc"
