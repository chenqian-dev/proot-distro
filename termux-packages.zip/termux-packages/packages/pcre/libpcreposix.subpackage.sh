TERMUX_SUBPKG_INCLUDE="lib/libpcreposix.so*"
TERMUX_SUBPKG_DESCRIPTION="Posix-compatible runtime libraries for libpcre"
