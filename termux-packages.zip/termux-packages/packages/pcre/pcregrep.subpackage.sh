TERMUX_SUBPKG_INCLUDE="bin/pcregrep share/man/man1/pcregrep.1.gz"
TERMUX_SUBPKG_DESCRIPTION="A grep with Perl-compatible regular expressions"
