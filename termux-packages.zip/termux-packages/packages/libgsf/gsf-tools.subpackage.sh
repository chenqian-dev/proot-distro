TERMUX_SUBPKG_INCLUDE="
bin/
share/man/man1/
share/thumbnailers/
"
TERMUX_SUBPKG_DESCRIPTION="Command-line tools for libgsf"
