TERMUX_SUBPKG_DESCRIPTION="Knot DNS utilities"
TERMUX_SUBPKG_INCLUDE="
bin/
share/man/man1/
"
TERMUX_SUBPKG_DEPENDS="libedit, libidn2, libnghttp2, resolv-conf"
