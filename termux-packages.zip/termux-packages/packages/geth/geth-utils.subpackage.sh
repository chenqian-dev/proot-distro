TERMUX_SUBPKG_DESCRIPTION="Additional utilities for Geth (like abigen, bootnode, evm, puppeth)"

TERMUX_SUBPKG_INCLUDE="
bin/abidump
bin/abigen
bin/bootnode
bin/clef
bin/devp2p
bin/ethkey
bin/evm
bin/faucet
bin/p2psim
bin/rlpdump"
