TERMUX_SUBPKG_INCLUDE="
lib/libnl-cli-*.a
lib/libnl-cli-*.la
lib/libnl/cli/**/*.a
lib/libnl/cli/**/*.la
"
TERMUX_SUBPKG_DESCRIPTION="Static libraries for libnl-cli"
TERMUX_SUBPKG_DEPENDS="libnl-cli"
