TERMUX_SUBPKG_DESCRIPTION="Command-line interface utilities for libnl"
TERMUX_SUBPKG_INCLUDE="
bin/
include/libnl*/netlink/cli/
lib/libnl-cli-*.so
lib/libnl/cli/
lib/pkgconfig/libnl-cli-*.pc
"
