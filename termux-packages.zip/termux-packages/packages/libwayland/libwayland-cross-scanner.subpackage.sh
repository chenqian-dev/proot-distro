TERMUX_SUBPKG_DESCRIPTION="wayland-scanner for host (NOT for Termux)"
TERMUX_SUBPKG_INCLUDE="
opt/$TERMUX_PKG_NAME/cross/*
"
