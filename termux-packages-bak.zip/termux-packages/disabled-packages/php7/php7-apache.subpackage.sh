TERMUX_SUBPKG_DESCRIPTION="Apache 2.0 Handler module for PHP"
TERMUX_SUBPKG_DEPENDS="apache2"
TERMUX_SUBPKG_INCLUDE="libexec/apache2/libphp7.so"
