TERMUX_SUBPKG_INCLUDE="bin/php-fpm etc/php-fpm.* share/man/man8/php-fpm.8.gz var/service/php-fpm"
TERMUX_SUBPKG_CONFFILES="etc/php-fpm.conf etc/php-fpm.d/www.conf"
TERMUX_SUBPKG_DESCRIPTION="FastCGI Process Manager for PHP"
TERMUX_SUBPKG_CONFLICTS="php-fpm"
