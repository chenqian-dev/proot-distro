TERMUX_SUBPKG_INCLUDE="opt/openjdk-17/lib/security/"
TERMUX_SUBPKG_DESCRIPTION="Common CA certificates (java keystore format)"
TERMUX_SUBPKG_PLATFORM_INDEPENDENT=true
