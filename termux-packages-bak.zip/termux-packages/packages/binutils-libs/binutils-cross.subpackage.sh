TERMUX_SUBPKG_DESCRIPTION="GNU Binutils for cross build on the host (NOT for Termux)"
TERMUX_SUBPKG_INCLUDE="opt/binutils/cross/"
TERMUX_SUBPKG_DEPEND_ON_PARENT=no
